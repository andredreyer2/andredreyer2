# Source Code Management & CI/CD Compromise

:warning: Content of this page has been moved to [InternalAllTheThings/cheatsheets/source-code-management-ci](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/)

* [Tools](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/#tools)
* [Enumerate repositories files and secrets](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/#enumerate-repositories-files-and-secrets)
* [Personal Access Token](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/#personal-access-token)
* [Gitlab CI/Github Actions](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/#gitlab-cigithub-actions)
* [References](https://swisskyrepo.github.io/InternalAllTheThings/cheatsheets/source-code-management-ci/#references)