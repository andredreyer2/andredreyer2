#!/bin/bash
git submodule update --init --remote --depth=1 --progress