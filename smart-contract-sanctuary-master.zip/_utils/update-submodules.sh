#!/bin/bash
git submodule update --remote --progress