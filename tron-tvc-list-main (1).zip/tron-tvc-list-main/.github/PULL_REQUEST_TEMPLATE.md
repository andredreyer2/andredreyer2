## **Please provide the following information for your token.**

Please include change to the `tokenlist.json` file in the PR.
DON'T modify any other token on the list.

At minimum each entry should have

- Token Address:
- Token Name:
- Token Symbol:
- Token Decimal:
- Logo URI: 
- Link to the official homepage of token:
- MarketCap Link if available (https://coinmarketcap.com/currencies/#TOKEN or https://www.coingecko.com/en/coins/#TOKEN):
- Existing Markets (where to trade): 
